#include "perso.h"
#include <stdio.h>
#include <stdlib.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_ttf.h>
#include <SDL/SDL_mixer.h>
void initPerso(Personne *p)
{
//perso
p->image1 =IMG_Load("perso.png");
p->image2 =IMG_Load("walk.png");
p->image3 =IMG_Load("arriere.png");
p->imagepersoAvant[0][0]=p->image1;
p->imagepersoAvant[1][0]=p->image2;
p->imagepersoAvant[2][0]=p->image3;
//death
p->image4 =IMG_Load("death etape 1.png");
p->image5 =IMG_Load("death etape 2.png");
p->imagepersoAvant[3][0]=p->image4;
p->imagepersoAvant[3][1]=p->image5;
//jump
p->image6 =IMG_Load("jump 2.png");
p->imagepersoAvant[4][0]=p->image6;
//SLAP
p->image7 =IMG_Load("slap 1.png");
p->image8 =IMG_Load("slap 2.png");
p->image9 =IMG_Load("slap 3.png");
p->image10=IMG_Load("slap 4.png");
p->imagepersoAvant[5][0]=p->image7;
p->imagepersoAvant[5][1]=p->image8;
p->imagepersoAvant[5][2]=p->image9;
p->imagepersoAvant[5][3]=p->image10;
//ULT
p->image11 =IMG_Load("hand + candy.png");
p->image12 =IMG_Load("candy ball.png");
p->imagepersoAvant[6][0]=p->image11;
/////////////////////////////////////////////
//perso
p->positionEcranPerso.x=0;
p->positionEcranPerso.y=705;
p->positionEcranPerso.h=p->image2->h;
p->positionEcranPerso.w=p->image2->w;
//ult
p->ult.x= p->positionEcranPerso.x + p->image11->w + 5;
p->ult.y= 742;
p->ult.h=p->image12->h;
p->ult.w=p->image12->w;
//score
p->score=IMG_Load("back1.png");
p->positionEcranScore.x=10;
p->positionEcranScore.y=40;
p->positionEcranScore.h=p->score->h;
p->positionEcranScore.w=p->score->w;
//vie
p->vie=IMG_Load("BACK.png");
p->positionEcranVie.x=50;
p->positionEcranVie.y=80;
p->positionEcranVie.h=p->vie->h;
p->positionEcranVie.w=p->vie->h;
//vitesse et acc
p->vitesse=5;
p->acceleration=0;
}
////////////////////////////////PERSO2/////////////////////////////////
void initPerso2(Personne *p1)
{
//pers
//stand and walk
p1->image1 =IMG_Load("stand1.png");
p1->image2 =IMG_Load("walk1.png");
p1->imagepersoAvant[0][0]=p1->image1;
p1->imagepersoAvant[1][0]=p1->image2;
//jump
p1->image3 =IMG_Load("jump1.png");
p1->imagepersoAvant[4][0]=p1->image3;
//ATTA
p1->image4 =IMG_Load("att 1.png");
p1->image5 =IMG_Load("att 2.png");
p1->image6 =IMG_Load("att 3.png");
p1->image7 =IMG_Load("att 4.png");
p1->image8 =IMG_Load("att 5.png");
p1->imagepersoAvant[5][0]=p1->image4;
p1->imagepersoAvant[5][1]=p1->image5;
p1->imagepersoAvant[5][2]=p1->image6;
p1->imagepersoAvant[5][3]=p1->image7;
p1->imagepersoAvant[5][4]=p1->image7;

p1->positionEcranPerso.x=0;
p1->positionEcranPerso.y=715;
p1->positionEcranPerso.h=p1->image1->h;
p1->positionEcranPerso.w=p1->image1->w;
///////////////////////////////////
}
void afficher (Personne p ,SDL_Surface *screen,SDL_Rect Camera,SDL_Rect positionEcran,SDL_Surface *image)
{
SDL_BlitSurface(image ,&Camera,screen,&positionEcran);
}
////////////////////LEFT/////////////
void moveLeft(int *ligne,Personne *p,SDL_Rect *Camera,int *acc)
{
*ligne=2;
(*Camera).x-=20;
*acc = *acc +1;
if ( *acc < 4 )
{(*p).positionEcranPerso.x-=20;}
else {(*p).positionEcranPerso.x-=40;}
}
//////////////////RIGHT//////////////////////
void moveRight(int *ligne,Personne *p,SDL_Rect *Camera,int *acc)
{
*ligne=1;
(*Camera).x+=20;
//milieu de ecran//
if ((*p).positionEcranPerso.x <= (1550/2))
{
*acc = *acc +1;
if ( *acc < 4 )
{(*p).positionEcranPerso.x+=20;}
else {(*p).positionEcranPerso.x+=40;}
}
}
///////////////////JUMP///////////////////////////
void jump(int *ligne,Personne *p,SDL_Rect *Camera,int *acc,Personne *p1)
{
*ligne=4;
(*p).positionEcranPerso.y=640;
(*p1).positionEcranPerso.y=780;
(*Camera).y=0;
}
/////////////SLAP//////////////////////
void slap(int *ligne,int *colone,int *b)
{
*ligne =5;
if (*b==1)
{*colone = *colone +1;}
//etat final
if ( *colone == 3)
{*colone = 0;
*ligne=0;}
*b=1;
}
/////////////ULT///////////////////////
void ulti(int *ligne,int *colone,int *ult,Personne *p)
{
*ligne=6;
(*p).ult.x+=40;
//ULT DISTANCE
if ((*p).ult.x >=  (*p).positionEcranPerso.x + (*p).image11->w + 300)
{
*ligne=0;
*colone=0;
*ult=0;
}
else 
{
*ult=1;
}
}
/*
void movePerso(Personne *p,Uint32 dt)
{
float dx;
p->positionEcranPerso.x = (int)((p->acceleration) * (dt * dt))/2 + (dt * p->vitesse);
dx=((p->acceleration) * (dt * dt))/2 + (dt * p->vitesse);
printf("%.2f\n",dx);
}
*/

