#include "perso.h"
#include <stdio.h>
#include <stdlib.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_ttf.h>
#include <SDL/SDL_mixer.h>
//(Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, MIX_DEFAULT_CHANNELS, 1024) == -1)
void main()
{
///////////////////////////////////////////////////////////////////////////////DECLARATION///////////////////////////////////////////////////////////////////////////////////////////
SDL_Init (SDL_INIT_EVERYTHING);
TTF_Init();
//pers
Personne p,p1;
//enemy
SDL_Event event;
int c=1,mouseX,mouseY;
Uint32 dt, t_prev;
//screen
SDL_Surface *screen;
screen=SDL_SetVideoMode(2100,900,32,SDL_HWSURFACE | SDL_DOUBLEBUF);
//background
SDL_Surface *image;
image=IMG_Load("background1.PNG");
//pour perso 2:
//2backgrounds
//////////////
SDL_Rect positionEcran={0,0,image->w,image->h};
//pour perso 2:
//2 positions
//////////////
SDL_Rect Camera={0,100,image->w,image->h};
Uint8 *keys;
//LES FCTS
initPerso(&p);
initPerso2(&p1);
//pers1
int colone=0 , ligne=0 ,b=0,acc =0,ult=0;
//pers2
int perso2=0;
int colone1=0 , ligne1=0,acc1=0,b7=0;
/////////////////////////////////////////////////////BOUCLE DE JEU///////////////////////////////////////////////////////////////////////////////////////////////////////////
while (c)
{
t_prev=SDL_GetTicks();	//au début de la boucle de jeu
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////PERSO1///////////////////////////////////////////////////////////////////////
////ACCELERATION//////
//keys press test
keys=SDL_GetKeyState(NULL);
//Avant
if (keys[SDLK_RIGHT])
{
moveRight(&ligne,&p,&Camera,&acc);
}
//}
//ARRIERE
else if (keys[SDLK_LEFT])
{
moveLeft(&ligne,&p,&Camera,&acc);
}
/**/
//JUMP
else if (keys[SDLK_SPACE])
{
jump(&ligne,&p,&Camera,&acc,&p1);
}
//SLAP
else if (keys['e'])
{
slap(&ligne,&colone,&b);
}
//ULT 
else if (keys['r'])
{
ulti(&ligne,&colone,&ult,&p);
}
else {ligne=0;colone=0;b=0;p.positionEcranPerso.y=705,Camera.y=100,acc =0,ult=0,p.ult.x= p.positionEcranPerso.x + p.image11->w + 5;p1.positionEcranPerso.y=715;}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////PERSO2///////////////////////////////////////////////////////////////////////
if (perso2==1)
{

//Avant
if (keys['d'])
{
ligne1=1;
Camera.x+=20;
//milieu de ecran//
if (p1.positionEcranPerso.x <= (1550/2))
{
acc1 = acc1 +1;
if ( acc1 < 4 )
{p1.positionEcranPerso.x+=20;}
else {p1.positionEcranPerso.x+=40;}
}
}
//JUMP
else if (keys['z'])
{
ligne1=4;
p1.positionEcranPerso.y=700;
p.positionEcranPerso.y=780;
Camera.y=0;
}
//ATTA
else if (keys['x'])
{
ligne1=5;
if  (b7 == 1)
{
colone1=colone1+1;
if (colone1 >= 4)
{
colone1 = 4;
colone1=0;
}
}
b7=1;
}

else {ligne1=0;colone1=0;acc1=0;p.positionEcranPerso.y=705,b7=0;}
}


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////END OF BACKGROUND/////////////////////////////////////////////////////////////////
if (Camera.x<=0)
{Camera.x=0;}

if (Camera.x + screen->w  >= image->w)
{Camera.x=0;}
//p.acceleration-=0.001;
/////////////////////////////////////////////////////////////////////eventS//////////////////////////////////////////////////////////////////////////
while (SDL_PollEvent(&event))
{
switch (event.type)
{
case SDL_KEYDOWN:
if (event.key.keysym.sym == SDLK_ESCAPE)
{c=0;}
///////////////////////////////////////////////perso2
if(event.key.keysym.sym == 'm') 
{
perso2=!perso2;
}
break;
}//switch
}//event
////////////////////////////////////////////////////////////////////////////BLIT////////////////////////////////////////////////////////////////////////
//background
SDL_BlitSurface(image ,&Camera,screen,&positionEcran);
SDL_Delay(80);
/////////////////////////////////////////perso1
SDL_BlitSurface(p.imagepersoAvant[ligne][colone] ,NULL,screen,&p.positionEcranPerso);
//ult
if (ult == 1)
{SDL_BlitSurface(p.image12 ,NULL,screen,&p.ult);}
//score
SDL_BlitSurface(p.score ,NULL,screen,&p.positionEcranScore);
//vie
SDL_BlitSurface(p.vie ,NULL,screen,&p.positionEcranVie);
///////////////////////////////////////perso2
if (perso2 == 1)
{SDL_BlitSurface(p1.imagepersoAvant[ligne1][colone1] ,NULL,screen,&p1.positionEcranPerso);}

dt=SDL_GetTicks()-t_prev;//à la fin de la boucle de jeu
SDL_Flip(screen);
}
//free
SDL_FreeSurface(screen);
SDL_FreeSurface(image);
SDL_FreeSurface(p.score);
SDL_FreeSurface(p.vie);
SDL_FreeSurface(p.image1);
SDL_FreeSurface(p.image2);
SDL_FreeSurface(p.image3);
SDL_FreeSurface(p.image4);
SDL_FreeSurface(p.image5);
SDL_FreeSurface(p.image6);
SDL_FreeSurface(p.image7);
SDL_FreeSurface(p.image8);
SDL_FreeSurface(p.image9);
SDL_FreeSurface(p.image11);
SDL_FreeSurface(p.image12);
SDL_Quit();
}
